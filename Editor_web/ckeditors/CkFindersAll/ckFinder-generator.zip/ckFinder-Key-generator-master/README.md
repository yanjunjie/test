# ckFinder-Key-generator

Generator Key for ckFinder version 2.x

# Hướng dẫn

Chạy file Index.html, điền License Name tùy thích, ấn Generate và thưởng thức License Key.