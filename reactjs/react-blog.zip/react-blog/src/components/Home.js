import React from 'react';

export class Home extends React.Component {
    render() {
        return (
            <React.Fragment>
                <article className={'article_area'}>
                    <div className="container article">
                        <h2>Home</h2>
                        <p>This is really home page. I am very very sure and over confident about that. This is absolutely right</p>
                        <p>Nothing to do if you don't believe me</p>
                        <p>This is really home page. I am very very sure and over confident about that</p>
                        <p>Nothing to do if you don't believe me</p>
                        <p>This is really home page. I am very very sure and over confident about that</p>
                        <p>Nothing to do if you don't believe me</p>
                        <p>This is really home page. I am very very sure and over confident about that</p>
                        <p>Nothing to do if you don't believe me</p>
                        <p>This is really home page. I am very very sure and over confident about that</p>
                        <p>Nothing to do if you don't believe me</p>
                    </div>
                </article>
            </React.Fragment>
        );
    }
}

