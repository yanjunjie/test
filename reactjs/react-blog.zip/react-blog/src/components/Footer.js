import React, {Component} from 'react';
class Footer extends Component{
    render() {
        return (
            <footer className={'footer_area'}>
                <div className="container footer">
                    <p>Copyright &copy; 2019, All Rights Reserved</p>
                </div>
            </footer>
        );
    }
}

export default Footer;
